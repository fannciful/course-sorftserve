# React online marathon

## The tasks of the topic "Webpack"

There is the file <code>webpack.config.js</code>

Configure it to specify:

1. Define the path <code>./src/main.js</code> as an entry property in your webpack configuration
2. Your configuration should output a single <code>build.js</code> file into the <code>pub</code> directory
