import styles from './button.module.css';

function Button() {
  return <button className={styles.active}>Click Me</button>;
}

export default Button;
