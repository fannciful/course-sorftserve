# React Practical
## Using CSS Modules

Please, create CSS modules for Button and Input.
These modules should define a class with the same name 'active'.
 - For Button the class should define background-color as lightblue
 - For Input the class should define background-color as azure
