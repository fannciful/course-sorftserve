import Image from 'next/image';
import cardStyle from '@/styles/Card.module.css';
import mapPinIcon from '@/assets/images/map-pin.png';

export default function Card({ data }) {

  return (
      <div className={cardStyle.card}>
        <div className={cardStyle.content}>
          <Image
              className={cardStyle.picture}
              src={data.imageUrl}
              alt={`a picture of ${data.title}`}
              width="395"
              height="263"
          />
          <div className={cardStyle.textBox}>
            <div className={cardStyle.textLocationBox}>
              <Image className={cardStyle.textlLocationLogo} src={mapPinIcon} alt="a map pin" />
              <span className={cardStyle.textLocationCountry}>{data.location}</span>
              <a href={data.googleMapsUrl}>View on Google Maps</a>
            </div>
            <h1 className={cardStyle.textTitle}>{data.title}</h1>
            <p className={cardStyle.textTravelDates}>{`${data.startDate} - ${data.endDate}`}</p>
            <p className={cardStyle.Description}>{data.description}</p>
          </div>
        </div>
      </div>
  )
}
