'use client';

import React, { useState, useEffect } from 'react';
import TaskItem from './TaskItem';

export interface Task {
  id: number;
  text: string;
  completed: boolean;
}

interface TaskListProps {
  tasks?: Task[];
}

const TaskList: React.FC<TaskListProps> = ({ tasks: initialTasks }) => {
  const [tasks, setTasks] = useState<Task[]>([]);
  const [newTaskText, setNewTaskText] = useState('');
  const [isMounted, setIsMounted] = useState(false);

  useEffect(() => {
    setIsMounted(true);
  }, []);

  useEffect(() => {
    if (!isMounted) return;

    if (initialTasks && initialTasks.length > 0) {
      setTasks(initialTasks);
      localStorage.setItem('tasks', JSON.stringify(initialTasks));
    } else {
      try {
        const storedTasks = localStorage.getItem('tasks');
        if (storedTasks) {
          const parsedTasks = JSON.parse(storedTasks);
          if (Array.isArray(parsedTasks)) {
            setTasks(parsedTasks);
          }
        }
      } catch (error) {
        console.error('Error loading tasks from localStorage:', error);
        setTasks([]);
      }
    }
  }, [initialTasks, isMounted]);

  useEffect(() => {
    if (isMounted) {
      localStorage.setItem('tasks', JSON.stringify(tasks));
    }
  }, [tasks, isMounted]);

  const handleAddTask = () => {
    const trimmedText = newTaskText.trim();
    if (trimmedText === '') return;

    const newTask: Task = {
      id: Date.now(),
      text: trimmedText,
      completed: false,
    };

    setTasks(prevTasks => [...prevTasks, newTask]);
    setNewTaskText('');
  };

  const handleRemoveTask = (id: number) => {
    setTasks(prevTasks => prevTasks.filter(task => task.id !== id));
  };

  const handleToggleTask = (id: number) => {
    setTasks(prevTasks =>
      prevTasks.map(task =>
        task.id === id ? { ...task, completed: !task.completed } : task
      )
    );
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      handleAddTask();
    }
  };

  if (!isMounted) {
    return (
      <div className="task-list">
        <h1 className="task-list-title">Task List</h1>
        <p>Loading...</p>
      </div>
    );
  }

  return (
    <div className="task-list">
      <h1 className="task-list-title">Task List</h1>
      
      <div className="add-task-form">
        <input
          type="text"
          value={newTaskText}
          onChange={(e) => setNewTaskText(e.target.value)}
          onKeyDown={handleKeyPress}  
          placeholder="Enter a new task..."
          className="add-task-input"
        />
        <button 
          onClick={handleAddTask} 
          className="add-task-button"
          disabled={newTaskText.trim() === ''}
        >
          Add
        </button>
      </div>

      {tasks.length === 0 ? (
        <p className="task-list-empty">No tasks to display</p>
      ) : (
        <div>
          {tasks.map(task => (
            <TaskItem
              key={task.id}
              task={task}
              onRemove={handleRemoveTask}
              onToggle={handleToggleTask}
            />
          ))}
        </div>
      )}
    </div>
  );
};

export default TaskList;