'use client';

import React from 'react';
import { Task } from './TaskList';

interface TaskItemProps {
  task: Task;
  onRemove: (id: number) => void;
  onToggle: (id: number) => void;
}

const TaskItem: React.FC<TaskItemProps> = ({ task, onRemove, onToggle }) => {
  const handleCheckboxChange = () => {
    onToggle(task.id);
  };

  const handleRemoveClick = () => {
    onRemove(task.id);
  };

  return (
    <div className="task-item">
      <div style={{ display: 'flex', alignItems: 'center', flex: 1 }}>
        <input
          type="checkbox"
          checked={task.completed}
          onChange={handleCheckboxChange}
          className="task-item-checkbox"
        />
        <span 
          className="task-item-text"
          style={{ 
            textDecoration: task.completed ? 'line-through' : 'none',
            opacity: task.completed ? 0.7 : 1
          }}
        >
          {task.text}
        </span>
      </div>
      <button
        onClick={handleRemoveClick}
        className="task-item-remove-button"
        aria-label={`Remove task: ${task.text}`}
      >
        Remove
      </button>
    </div>
  );
};

export default TaskItem;