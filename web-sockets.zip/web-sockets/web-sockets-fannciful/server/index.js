const WebSocket = require('ws');

const wss = new WebSocket.Server({ port: 8082 });

const isTest = process.env.NODE_ENV === 'test';

wss.on('connection', function connection(ws) {
    if (!isTest) console.log('New client connected');
    
    ws.on('message', function incoming(message) {
        if (!isTest) console.log('Received:', message.toString());
        
        wss.clients.forEach(function each(client) {
            if (client.readyState === WebSocket.OPEN) {
                client.send(message.toString());
            }
        });
    });
    
    ws.on('close', function() {
        if (!isTest) console.log('Client disconnected');
    });
    
    ws.on('error', function(error) {
        if (!isTest) console.error('WebSocket error:', error);
    });
});

if (!isTest) {
    console.log('WebSocket server running on port 8082');
}

wss.close = function(callback) {
    this.clients.forEach(function each(client) {
        if (client.readyState === WebSocket.OPEN) {
            client.close();
        }
    });
    
    this._server.close(() => {
        if (callback) callback();
    });
};

module.exports = wss;