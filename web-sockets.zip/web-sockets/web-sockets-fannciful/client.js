const remoteUrl = 'wss://ws.postman-echo.com/raw';
const localUrl = 'ws://localhost:8082';

// Your implementation 
const ws = new WebSocket(localUrl);

ws.onopen = function() {
    console.log('Connected to WebSocket server');
};

ws.onmessage = function(event) {
    const message = event.data;
    const chat = document.getElementById('chat');
    chat.value += message + '\n';
    chat.scrollTop = chat.scrollHeight;
};

ws.onerror = function(error) {
    console.error('WebSocket error:', error);
    alert('Cannot connect to WebSocket server. Make sure server is running on port 8082.');
};

ws.onclose = function() {
    console.log('Disconnected from WebSocket server');
};

function send() {
    const userNameInput = document.getElementById('userName');
    const messageInput = document.getElementById('message');
    const nickname = userNameInput.value.trim();
    const message = messageInput.value.trim();

    if (!nickname) {
        alert('Please enter your nickname!');
        return;
    }

    if (!message) {
        alert('Please enter a message!');
        return;
    }

    if (ws.readyState === WebSocket.OPEN) {
        const fullMessage = `${nickname}: ${message}`;
        ws.send(fullMessage);
        messageInput.value = '';
    } else {
        alert('WebSocket is not connected. Please try again.');
    }
}

document.addEventListener('DOMContentLoaded', function() {
    const messageInput = document.getElementById('message');
    if (messageInput) {
        messageInput.addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                send();
            }
        });
    } else {
        console.error('Message input element not found');
    }
});