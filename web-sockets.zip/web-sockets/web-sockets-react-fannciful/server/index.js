const WebSocket = require('ws');

const wss = new WebSocket.Server({ port: 8082 });

const isTestEnvironment = process.env.NODE_ENV === 'test';

wss.on('connection', (ws) => {
    if (!isTestEnvironment) {
        console.log('New client connected!');
    }

    ws.on('message', (message) => {
        if (!isTestEnvironment) {
            console.log('Received:', message.toString());
        }

        wss.clients.forEach((client) => {
            if (client.readyState === WebSocket.OPEN) {
                client.send(message.toString());
            }
        });
    });

    ws.on('close', () => {
        if (!isTestEnvironment) {
            console.log('Client disconnected');
        }
    });

    ws.on('error', (error) => {
        if (!isTestEnvironment) {
            console.error('WebSocket error:', error);
        }
    });
});

if (!isTestEnvironment) {
    console.log('WebSocket server running on port 8082');
}

module.exports = wss;