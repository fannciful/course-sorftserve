import { useEffect, useState } from 'react';
import './App.css';

function App({ ws }) {
  const [messages, setMessages] = useState([]);
  const [nickname, setNickname] = useState('');
  const [message, setMessage] = useState('');

  useEffect(() => {
    const handleMessage = (event) => {
      const newMessage = event.data;
      setMessages(prev => [...prev, newMessage]);
    };

    ws.addEventListener('message', handleMessage);
  }, [ws]);

  const handleSend = () => {
    if (nickname.trim() && message.trim()) {
      const fullMessage = `${nickname}: ${message}`;
      ws.send(fullMessage);
      setMessage('');
    }
  };

  const handleKeyPress = (e) => {
    if (e.key === 'Enter') {
      handleSend();
    }
  };

  return (
    <div className="App">
      <h1>Web Sockets</h1>
      <div>
        <textarea 
          rows="30" 
          cols="60" 
          readOnly 
          aria-label="chat"
          value={messages.join('\n')} 
        />
      </div>
      <input 
        placeholder="Your nickname" 
        size="11" 
        value={nickname} 
        onChange={(e) => setNickname(e.target.value)} 
      />
      <input 
        placeholder="Type your message" 
        size="40" 
        value={message}
        onChange={(e) => setMessage(e.target.value)} 
        onKeyPress={handleKeyPress}
      />
      <button onClick={handleSend}>Send</button>
    </div>
  );
}

export default App;