import getGitHubUser from '../services/DataService';
import axios from 'axios';

jest.mock('axios');

describe("DataService", () => {
  beforeEach(() => {
    axios.get.mockClear();
  });

  it("should fetch user data from GitHub API", async () => {
    const mockUser = 'testuser';
    const mockResponse = {
      data: {
        login: 'testuser',
        name: 'Test User',
        bio: 'Test bio'
      }
    };
    
    axios.get.mockResolvedValue(mockResponse);

    const result = await getGitHubUser(mockUser);

    expect(axios.get).toHaveBeenCalledTimes(1);
    expect(axios.get).toHaveBeenCalledWith(`https://api.github.com/users/${mockUser}`);
    expect(result).toEqual(mockResponse);
  });

  it("should handle API errors", async () => {
    const mockUser = 'nonexistentuser';
    
    axios.get.mockRejectedValue(new Error('User not found'));

    await expect(getGitHubUser(mockUser)).rejects.toThrow('User not found');
    expect(axios.get).toHaveBeenCalledWith(`https://api.github.com/users/${mockUser}`);
  });
});