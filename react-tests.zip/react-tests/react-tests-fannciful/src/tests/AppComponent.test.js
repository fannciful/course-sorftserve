import React from 'react';
import { render, screen } from '@testing-library/react';
import App from '../components/App'; 

jest.mock('../components/Info', () => {
  return function MockInfo({ user }) {
    return <div data-testid="info-component">Info for {user}</div>;
  };
});

describe("App Component", () => {
  it("should render main heading and Info components", () => {
    render(<App />);
    
    expect(screen.getByText('Hello World!')).toBeInTheDocument();
    
    const infoComponents = screen.getAllByTestId('info-component');
    expect(infoComponents).toHaveLength(2);
  });

  it("should have correct CSS class", () => {
    const { container } = render(<App />);
    
    expect(container.querySelector('.App')).toBeInTheDocument();
  });
});