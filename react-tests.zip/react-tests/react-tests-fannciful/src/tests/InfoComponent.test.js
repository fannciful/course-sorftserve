import React from 'react';
import { render, screen, waitFor } from '@testing-library/react';
import Info from '../components/Info';
import getGitHubUser from '../services/DataService';

jest.mock('../services/DataService');

describe("Info Component", () => {
  beforeEach(() => {
    getGitHubUser.mockClear();
  });

  it("should display user data when API call succeeds", async () => {
    const mockUserData = {
      login: 'testuser',
      name: 'Test User',
      bio: 'Test bio',
      public_repos: 5
    };
    
    getGitHubUser.mockResolvedValue({ data: mockUserData });

    render(<Info user="testuser" />);

    expect(screen.getByText('GitHub User Info')).toBeInTheDocument();

    await waitFor(() => {
      expect(screen.getByText('login: testuser')).toBeInTheDocument();
      expect(screen.getByText('name: Test User')).toBeInTheDocument();
    });

    expect(getGitHubUser).toHaveBeenCalledWith('testuser');
  });

  it("should display error message when API call fails", async () => {
    getGitHubUser.mockRejectedValue(new Error('API Error'));

    render(<Info user="invaliduser" />);

    await waitFor(() => {
      expect(screen.getByText('error: request error')).toBeInTheDocument();
    });
  });
});