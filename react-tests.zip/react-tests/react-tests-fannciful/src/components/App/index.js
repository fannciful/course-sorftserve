import Info from "../Info";

function App() {
    return (
      <div className="App">
        <h1>Hello World!</h1>
        <Info user="yurkovskiy" />
        <Info user="mplesha" />
      </div>
    );
  }
  
  export default App;
  