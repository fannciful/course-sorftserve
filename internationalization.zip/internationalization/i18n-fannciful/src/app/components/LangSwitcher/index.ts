export { default } from './LangSwitcher';
