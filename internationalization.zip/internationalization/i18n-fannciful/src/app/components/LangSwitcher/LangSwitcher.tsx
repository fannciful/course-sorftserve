'use client';
import { useTranslations, useLocale } from 'next-intl';
import { usePathname, useRouter } from '@/i18n/routing';
import styles from './LangSwitcher.module.css';

interface LangSwitcherProps {
  caption: string;
}

export default function LangSwitcher({ caption }: LangSwitcherProps) {
  const t = useTranslations();
  const locale = useLocale();
  const pathname = usePathname();
  const router = useRouter();

  const handleLanguageChange = (event: React.ChangeEvent<HTMLSelectElement>) => {
    const newLocale = event.target.value;
    router.replace(pathname, { locale: newLocale });
  };

  return (
    <label>
      <span className={styles.label}>{caption}</span>
      <select
        className={styles.select}
        defaultValue={locale}
        onChange={handleLanguageChange}
      >
        <option value="en">English</option>
        <option value="uk">Українська</option>
      </select>
    </label>
  );
}