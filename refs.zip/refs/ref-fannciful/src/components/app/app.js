import React from 'react';

import './app.css';

import Input from '../input/input.js';

export default function App(){
    return <div data-testid="element-app" className="wrapper-app"><Input /></div>
}