import React, { useEffect, useRef } from 'react';
import { useState } from 'react';

import './input.css';


const Input = () => {
    const [operator, setOperator] = useState('');
    const [phone, setPhone] = useState('');
    const [operatorName, setOperatorName] = useState('');

    const operatorInputRef = useRef(null);
    const phoneInputRef = useRef(null);
    const checkIconRef = useRef(null);

    // автофокус на поле оператора при завантаженні компонента
    useEffect(() => {
        if (operatorInputRef.current) {
            operatorInputRef.current.focus();
        }
    }, []);

    // функція для визначення мобільного оператора за кодом 
    const getOperatorName = (code) => {
        const kyivstar = ['67', '68', '96', '97', '98'];
        const vodafone = ['50', '66', '95', '99'];
        const lifecell = ['63', '73', '93'];
        const mob3 = ['91'];
        const peopleNet = ['92'];
        const intertelecom = ['89', '94'];

        if (kyivstar.includes(code)) return 'Kyivstar';
        if (vodafone.includes(code)) return 'Vodafone';
        if (lifecell.includes(code)) return 'Lifecell';
        if (mob3.includes(code)) return '3mob';
        if (peopleNet.includes(code)) return 'People.net';
        if (intertelecom.includes(code)) return 'intertelecom';
        return 'Unknown';
    };

    // обробник введення для поля оператора
    const handleOperatorInput = (e) => {
        let value = e.target.value;
        value = value.replace(/\D/g, '');
        if (value.length > 2) {
            value = value.slice(0, 2);
        }
        setOperator(value);

        if (value.length === 2) {
            const name = getOperatorName(value);
            setOperatorName(name);
            setTimeout(() => {
                if (phoneInputRef.current) {
                    phoneInputRef.current.focus();
                }
            }, 0);
        } else {
            setOperatorName('');
        }
    };

    // обробник введення для поля телефону
    const handlePhoneInput = (e) => {
        let value = e.target.value;
        value = value.replace(/\D/g, '');
        if (value.length > 7) {
            value = value.slice(0, 7);
        }
        setPhone(value);
    };

    // ефект для оновлення іконки перевірки
    useEffect(() => {
        if (checkIconRef.current) {
            if (operator.length === 2 && phone.length === 7) {
                checkIconRef.current.textContent = ' ✔️ ';
            } else {
                checkIconRef.current.textContent = ' - ';
            }
        }
    }, [operator, phone]);

    return (
        <div>
            <span data-testid="operator-name">{operatorName}</span>
            <span>+38 0</span>
            <input
                ref={operatorInputRef}
                type="text"
                data-testid="operator-input"
                value={operator}
                onInput={handleOperatorInput}
                maxLength={2}
            />
            <span ref={checkIconRef} data-testid="check-icon"> - </span>
            <input
                ref={phoneInputRef}
                type="text"
                data-testid="phone-input"
                value={phone}
                onInput={handlePhoneInput}
                maxLength={7}
            />
        </div>
    );
}


export default Input;
