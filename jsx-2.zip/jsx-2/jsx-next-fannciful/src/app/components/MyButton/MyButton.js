import React from 'react'

function MyButton() {
  return (
    <button data-testid="element-button">
      Add to account
    </button>
  )
}

export default MyButton
