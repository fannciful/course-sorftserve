import React from 'react'

function MyInput() {
  return (
    <input id="inp-num" type='number' data-testid="element-input" />
  )
}

export default MyInput
