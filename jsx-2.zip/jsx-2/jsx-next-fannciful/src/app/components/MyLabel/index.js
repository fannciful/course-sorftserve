export { default } from "./MyLabel";
