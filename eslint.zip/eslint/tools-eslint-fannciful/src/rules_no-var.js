var val = 'using var';
alert(val);
