let a = 0;

if (a === 0) a += 2;
