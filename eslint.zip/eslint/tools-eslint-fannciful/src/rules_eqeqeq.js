const val = 'using ==';

if (val == '') {
    alert(val);
}
