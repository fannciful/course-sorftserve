let val;

if (val = val === 'condition') {
    alert(val);
}