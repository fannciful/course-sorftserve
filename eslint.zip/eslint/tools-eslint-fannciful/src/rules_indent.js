const returnZero = () => {
  return 0;
}

returnZero();
