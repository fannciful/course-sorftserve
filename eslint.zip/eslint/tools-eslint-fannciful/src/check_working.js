function f() {
    return 1;
}

f();
