console.log('Demo od console.log');
