const val = 'wrong string';
alert(val);
