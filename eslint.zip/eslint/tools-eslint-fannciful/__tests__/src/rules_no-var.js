const val = 'using var';
alert(val);
