const val = 1 + 1;
alert(val);
