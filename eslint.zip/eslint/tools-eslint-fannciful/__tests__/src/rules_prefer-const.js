const val = 'using let for never reassigned';

alert(val);
