const val = 'demo of extra semi';

alert(val);
