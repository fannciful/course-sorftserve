import { useState, useEffect } from 'react';

export const useLoading = (fetchMethod) => {
    const [data, setData] = useState(null);

    useEffect(() => {
        setData(null);
        fetchMethod().then((res) => {
            setData(res);
        });
    }, [fetchMethod]);

    return data;
};
