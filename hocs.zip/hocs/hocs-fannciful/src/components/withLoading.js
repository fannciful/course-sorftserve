import React, { useEffect, useState } from 'react'

const withLoading = (WrappedComponent) => {
    return function WithLoadingComponent(props) {
        const [data, setData] = useState(null);
        const [isLoading, setIsLoading] = useState(true);

        useEffect(() => {
            const fetchData = async () => {
                try {
                    setIsLoading(true);
                    const result = await props.fetchMethod(props.params);
                    setData(result);
                } catch (error) {
                    console.error('Error fetching data:', error);
                    setData(null);
                } finally {
                    setIsLoading(false);
                }
            };
            fetchData();
        }, [props.fetchNethod, props.params]);
       
        if (isLoading) {
            return <p className='center'>Loading...</p>
        };

        return <WrappedComponent {...props} data={data} />;
    };
};

export default withLoading;
