import { ErrorBoundary } from 'react-error-boundary';
import DataItem from './DataItem';
import ErrorFallback from './ErrorFallback';

function DataList() {
  return (
    <div>
      <h2>Data List</h2>
      {[1, 2, 3].map((index) => (
        <ErrorBoundary 
          key={index} 
          FallbackComponent={ErrorFallback}
        >
          <DataItem />
        </ErrorBoundary>
      ))}
    </div>
  );
}

export default DataList;