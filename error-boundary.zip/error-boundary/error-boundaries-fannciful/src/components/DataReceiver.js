import { useState } from "react";
import { getData } from "../api";

function DataReceiver() {
  const [data, setData] = useState(0);
  const [error, setError] = useState(null);

  if (error) {
    throw error;
  }

  const handleClick = () => {
    try {
      const newData = getData();
      setData(newData);
    } catch (err) {
      setError(err);
    }
  };

  return (
    <div className="data">
      <button onClick={handleClick}>Get new data</button>
      <div>{data}</div>
    </div>
  );
}

export default DataReceiver;