import { ErrorBoundary } from 'react-error-boundary';
import DataReceiver from './DataReceiver';
import ErrorFallback from './ErrorFallback';

function DataReceiverWithBoundary() {
  return (
    <div>
      <h2>Data Receiver</h2>
      <ErrorBoundary FallbackComponent={ErrorFallback}>
        <DataReceiver />
      </ErrorBoundary>
    </div>
  );
}

export default DataReceiverWithBoundary;