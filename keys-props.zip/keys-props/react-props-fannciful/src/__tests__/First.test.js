import { render, screen } from '@testing-library/react';
import First from '../First';

describe('First Component', () => {
  test('renders the first item from the props', () => {
    const firstList = ['test item', 'second item', 'third item'];

    render(<First firstList={firstList} />);

    expect(screen.getByText(new RegExp(firstList[0], 'i'))).toBeInTheDocument();
    expect(screen.queryByText(new RegExp(firstList[1], 'i'))).not.toBeInTheDocument();
  });
});
