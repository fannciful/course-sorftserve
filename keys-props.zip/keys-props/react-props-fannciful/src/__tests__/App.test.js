import { render, screen } from '@testing-library/react';

import App from '../App';

const expectedHeader = 'Some data';
const expectedData = 'Animals';

describe('App Component', () => {
  test('renders "Some data:" and the first item from the list', () => {
    render(<App />);

    expect(screen.getByText(new RegExp(expectedHeader, 'i'))).toBeInTheDocument();
    expect(screen.getByText(new RegExp(expectedData, 'i'))).toBeInTheDocument();
  });
});
