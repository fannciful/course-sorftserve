function First({ firstList }) {
    return (
        <div>
            {firstList[0]}
        </div>
    );
}

export default First;