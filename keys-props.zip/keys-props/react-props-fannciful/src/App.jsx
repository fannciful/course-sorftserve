import './App.css';
import First from './First';

export default function App() {
    const items = [
    "Animals",
    "Anime",
    "Anti-Malware",
    "Art Design",
    "Books",
    "Business",
    "Calendar",
    "Cloud Storage",
    "File Sharing",
    "Animals",
    "Continuous Integration",
    "Cryptocurrency"
  ];

  const firstList = items.map(item => item.toLowerCase());

  return(
    <div>
     <div>Some data:</div> 
      <First firstList={firstList} />
    </div>
  );
};
