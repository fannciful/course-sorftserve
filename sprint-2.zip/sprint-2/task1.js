/*
Створіть клас Movie, конструктор якого приймає 3 параметри: назву фільму name, жанр фільму category та рік початку показу 
startShow.

Клас має мати метод watchMovie(), який повертає фразу та додає до неї в кінці параметр з назвою фільму name. 
Наприклад: "Я дивлюсь фільм Titanic!".

Створіть екземпляр класу movie1 з назвою фільму "Titanic", жанром "драма" та роком виходу 1997.

Створіть екземпляр класу movie2 з назвою фільму "Troya", жанром "історичний" та роком виходу 2004.
*/


class Movie {
   constructor(name, category, startShow) {
    this.name = name;
    this.category = category;
    this.startShow = startShow;
   }

    watchMovie() {
        return `I watched the movie ${this.name}!`;
    }

}

const movie1 = new Movie("Titanic", "drama", 1997);
const movie2 = new Movie("Troya", "historical", 2004);
console.log(movie1.watchMovie());
console.log(movie2.watchMovie());
