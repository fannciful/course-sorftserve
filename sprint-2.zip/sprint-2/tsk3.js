/*
Конструктор MyProduct повинен забезпечувати генерацію унікального ідентифікатора товару (product id) в межах додатки, 
незалежно від того, скільки товарів буде створено.

Distributor може зберігати інформацію про товари у своїй властивості products і має можливість додавати та видаляти товар.

addProduct додає нову властивість до products з назвою (ім'ям ключа) у вигляді ідентифікатора товару та значенням - 
назвою товару.

removeProduct видаляє властивість з вказаним ідентифікатором з products.

Будь ласка, використовуйте тип даних Symbol.
*/

class Distributor {
    constructor() {
        this.products = {};
    }
    
    addProduct(id, name) {
       this.products[id] = name;
    }
    
    removeProduct(id) {
        delete this.products[id];
    }

    getProducts() {
        return this.products;
    }
}

const localDistributor = new Distributor();

class MyProduct{
    constructor(name){
        this.id = Symbol(name);
        this.name = name;
    }
    
    distribute(distributor){
        distributor.addProduct(this.id, this.name);
    }

    getId() {
        return this.id;
    }

    getName() {
        return this.name;
    }
}

const product1 = new MyProduct('iPhone 15');
const product2 = new MyProduct('Samsung Galaxy');
const product3 = new MyProduct('Xiaomi Mi');

product1.distribute(localDistributor);
product2.distribute(localDistributor);
product3.distribute(localDistributor);

const allProducts = localDistributor.getProducts();

localDistributor.removeProduct(product2.getId());

const productsAfterRemoval = localDistributor.getProducts();