/*
Реалізуйте клас PizzaMaker, який дозволяє створювати піцу різних типів, з різними інгредієнтами, розраховувати ціну та 
калорійність піци.

Піца буває 3 розмірів: S, M та L.

Доступні 4 типи піци: м'ясна, рибна, сирна та вегетаріанська.

При створенні нової піци обов'язково вказуйте розмір та тип.

Доступні додаткові інгредієнти, які можна додати до піци за бажанням клієнта: помідори, перець, бекон та оливки.

Кожен елемент, що входить до складу піци, має свою назву, ціну та калорійність. Всі ці дані містяться в об'єкті pizzaMenu.

Клас PizzaMaker має ряд методів для створення піци:

Метод addIngredient(ingredient) додає додатковий інгредієнт до піци. Новий інгредієнт додається, якщо він не входить до піци, 
і в консоль виводиться повідомлення 
"ingredient_name has been added". Якщо такий інгредієнт вже додано, генерується повідомлення "Such an ingredient already 
exists!".
Метод deleteIngredient(ingredient) видаляє вказаний інгредієнт зі списку наявних інгредієнтів, виводить у консоль 
повідомлення "ingredient_name has been deleted".
Метод getIngredients() повертає список доданих інгредієнтів з їх назвою, ціною, калорійністю.
Метод getSize() повертає розмір піци.
Метод getKind() повертає тип піци.
Метод calculatePrice() розраховує та повертає загальну вартість піци, яка складається із суми значень всіх її компонентів.
Метод calculateCalories() розраховує та повертає загальну калорійність піци, яка складається із суми калорій всіх її 
компонентів.
*/

const pizzaMenu = {
  SIZE_S: { param: 'SIZE_S', price: 60, calorie: 300 },
  SIZE_M: { param: 'SIZE_M', price: 90, calorie: 450 },
  SIZE_L: { param: 'SIZE_L', price: 110, calorie: 600 },
  KIND_MEAT: { param: 'KIND_MEAT', price: 55, calorie: 230 },
  KIND_FISH: { param: 'KIND_FISH', price: 70, calorie: 150 },
  KIND_CHEESE: { param: 'KIND_CHEESE', price: 50, calorie: 200 },
  KIND_VEGETARIAN: { param: 'KIND_VEGETARIAN', price: 35, calorie: 50 },
  INGREDIENT_TOMATOES: { param: 'INGREDIENT_TOMATOES', price: 15, calorie: 5 },
  INGREDIENT_PEPPER: { param: 'INGREDIENT_PEPPER', price: 18, calorie: 5 },
  INGREDIENT_BACON: { param: 'INGREDIENT_BACON', price: 25, calorie: 40 },
  INGREDIENT_OLIVES: { param: 'INGREDIENT_OLIVES', price: 20, calorie: 0 },
};

class PizzaMaker {
    constructor(size, kind) {
        this.size = size;
        this.kind = kind;
        this.ingredients = [];
    }

    addIngredient(ingredient) {
        if (this.ingredients.includes(ingredient)) {
            console.log("Such an ingredient already exists!");
        } else {
            this.ingredients.push(ingredient);
            console.log(`${ingredient.param} has been added`);
        }
    }

    deleteIngredient(ingredient) {
        const index = this.ingredients.indexOf(ingredient);
        if (index > -1) {
            this.ingredients.splice(index, 1);
            console.log(`${ingredient.param} has been deleted`);
        }
    }

    getIngredients() {
        return this.ingredients.map(ingredient => ({
            param: ingredient.param,
            price: ingredient.price,
            calorie: ingredient.calorie
        }));
    }

    getSize() {
        return this.size.param;
    }

    getKind() {
        return this.kind.param;
    }

    calculatePrice() {
        let total = this.size.price + this.kind.price;
        this.ingredients.forEach(ingredient => {
            total += ingredient.price;
        });
        return total;
    }

    calculateCalories() {
        let total = this.size.calorie + this.kind.calorie;
        this.ingredients.forEach(ingredient => {
            total += ingredient.calorie;
        });
        return total;
    }
}


const pizza = new PizzaMaker(pizzaMenu.SIZE_M, pizzaMenu.KIND_MEAT);
console.log("Size:", pizza.getSize());
console.log("Kind:", pizza.getKind());
console.log("calculatePrice:", pizza.calculatePrice());
console.log("calculateCalories:", pizza.calculateCalories());
pizza.addIngredient(pizzaMenu.INGREDIENT_OLIVES);
pizza.addIngredient(pizzaMenu.INGREDIENT_BACON);
console.log("calculatePrice:", pizza.calculatePrice());
console.log("calculateCalories:", pizza.calculateCalories());