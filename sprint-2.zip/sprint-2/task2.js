/*
Реалізуйте клас Student, конструктор якого приймає 2 параметри: fullName - ім'я та прізвище студента, direction - напрямок, 
на якому він навчається, та зберігає їх у приватних полях.

Створіть метод getFullName(), який повертає ім'я та прізвище студента.

Створіть метод nameIncludes(data), який перевіряє наявність текстового аргументу data в імені студента та повертає true, 
якщо знайдено збіг, або false, якщо не знайдено.

Створіть статичний метод studentBuilder(), який повертає новий екземпляр класу з іменем 'Ігор Когут' та напрямком 'qc'.

Створіть гетер та сетер direction() для читання та встановлення значення поля direction.

Створіть екземпляр класу stud1 з іменем 'Іван Петренко' та напрямком 'web'.

Створіть екземпляр класу stud2 з іменем 'Сергій Коваль' та напрямком 'python'.

Для коректного проходження всіх тестів не використовуйте метод console.log() у вашому коді.
Примітка: Редактор коду може відображати приватні поля як помилку, але це має працювати.


*/

class Student {
  #fullName;
  #direction;

  constructor(fullName, direction) {
    this.#fullName = fullName;
    this.#direction = direction;
  }

  getFullName() {
    return this.#fullName;
  }

  nameIncludes(data) {
    return this.#fullName.includes(data);
  }

  static studentBuilder() {
    return new Student('Ihor Kohut', 'qc');
  }

  get direction() {
    return this.#direction;
  }

  set direction(newDirection) {
    this.#direction = newDirection;
  }
}

const stud1 = new Student('Ivan Petrenko', 'web');
const stud2 = new Student('Sergiy Koval', 'python');

console.log(stud1);