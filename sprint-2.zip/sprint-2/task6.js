/*
**Переклад завдання:**

Реалізуйте клас `Plane`, конструктор якого приймає 3 параметри:
- `model` - модель літака
- `fuelSupply` - місткість запасу палива літака  
- `fuelConsumption` - середня витрата палива в літрах на 100 км польоту

Створіть метод класу `calcFlightRange()`, який визначає дальність польоту літака за формулою 
`fuelSupply / fuelConsumption * 100` і повертає її.

Створіть статичний метод класу `showSortedByFlightRange(planesArray)`, який приймає масив екземплярів 
класів `planesArray`, сортує дальність польоту літака в порядку зростання і виводить результат у консоль у 
форматі `plane_model: дальність`.

Створіть клас `TransportPlane`, який успадковується від класу `Plane`, конструктор якого приймає 5 параметрів:
- `model` - модель літака
- `fuelSupply` - кількість палива
- `fuelConsumption` - середня витрата палива в літрах на 100 км
- `cargo` - максимальна вантажопідйомність
- `addTank` - кількість додаткових баків літака

У цьому класі потрібно перевизначити метод `calcFlightRange()`, щоб врахувати, що `fuelSupply` збільшився на 
кількість палива, доданого через `addTank`.

Створіть клас `PassengerPlane`, який успадковується від класу `Plane`, конструктор якого приймає 5 параметрів:
- `model` - модель літака
- `fuelSupply` - кількість палива
- `fuelConsumption` - середня витрата палива
- `passengers` - максимальна кількість пасажирів
- `refueling` - кількість додаткового палива, отриманого при заправці

У цьому класі потрібно перевизначити метод `calcFlightRange()`, щоб врахувати, що `fuelSupply` збільшився на `refueling`.

Створіть клас `WarPlane`, який успадковується від класу `Plane`, конструктор якого приймає 5 параметрів:
- `model` - модель літака
- `fuelSupply` - кількість палива
- `fuelConsumption` - середня витрата палива
- `missiles` - кількість ракетного озброєння
- `aerodynamicsKoef` - коефіцієнт аеродинаміки літака

У цьому класі потрібно перевизначити метод `calcFlightRange()` таким чином, щоб врахувати, що дальність польоту літака 
збільшується пропорційно значенню коефіцієнта аеродинаміки `aerodynamicsKoef`.
*/

class Plane {
    constructor(model, fuelSupply, fuelConsumption) {
        this.model = model;
        this.fuelSupply = fuelSupply;
        this.fuelConsumption = fuelConsumption;
    }

    calcFlightRange() {
        return this.fuelSupply / this.fuelConsumption * 100;
    }

    static showSortedByFlightRange(planesArray) {
        const sortedArray = [...planesArray];
        sortedArray.sort((a, b) => a.calcFlightRange() - b.calcFlightRange());
        
        sortedArray.forEach(plane => {
            console.log(`${plane.model}: ${plane.calcFlightRange()}`);
        });
    }
}

class TransportPlane extends Plane{
    constructor(model, fuelSupply, fuelConsumption, cargo, addTank){
        super(model, fuelSupply, fuelConsumption);
        this.cargo = cargo;
        this.addTank = addTank;
    }

    calcFlightRange() {
        const totalFuel = this.fuelSupply + this.addTank;
        return totalFuel / this.fuelConsumption * 100;
    }
}

class PassengerPlane extends Plane {
    constructor(model, fuelSupply, fuelConsumption, passengers, refueling){
        super(model, fuelSupply, fuelConsumption);
        this.passengers = passengers;
        this.refueling = refueling;
    }

    calcFlightRange() {
        const totalFuel = this.fuelSupply + this.refueling;
        return totalFuel / this.fuelConsumption * 100;
    }
}

class WarPlane extends Plane {
    constructor(model, fuelSupply, fuelConsumption, missiles, aerodynamicsKoef){
        super(model, fuelSupply, fuelConsumption);
        this.missiles = missiles;
        this.aerodynamicsKoef = aerodynamicsKoef;
    }

    calcFlightRange() {
        const baseRange = this.fuelSupply / this.fuelConsumption * 100;
        return baseRange * this.aerodynamicsKoef;
    }
}

