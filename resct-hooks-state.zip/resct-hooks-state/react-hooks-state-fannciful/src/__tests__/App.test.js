import React from 'react';
import { render, cleanup, fireEvent, screen } from '@testing-library/react';
import App from '../App';

describe('Test suite for item "state-event"', () => {
  
  const expectedData = 'React Marathon';
  const expectedUpdatedData = 'react marathon';

  afterEach(cleanup);

  test('should render a div element', () => {
    render(<App />);
    const element = screen.getByText(new RegExp(expectedData, 'i'));
    expect(element.tagName).toBe('DIV');
  });

  test('should display the initial data correctly', () => {
    render(<App />);
    const element = screen.getByText(new RegExp(expectedData, 'i')).parentElement;
    expect(element).not.toBe(null);
  });

  test('should update data on click', () => {
    render(<App />);
    fireEvent.click(screen.getByText(expectedData));
    expect(screen.getByText(expectedUpdatedData)).toBeInTheDocument();
  });

  test('the updating action should work as a converter to lowercase text', () => {
    const originalUseState = React.useState;
    const stubInitialState = 'HELLO';
    const expectedUpdatedData = 'hello';

    jest.spyOn(React, 'useState');
    React.useState.mockImplementation(() => originalUseState(stubInitialState));

    render(<App />);
    fireEvent.click(screen.getByText(stubInitialState));
    expect(screen.getByText(expectedUpdatedData)).toBeInTheDocument();
    React.useState.mockRestore();
  });

});
