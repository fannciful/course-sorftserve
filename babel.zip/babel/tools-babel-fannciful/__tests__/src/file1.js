const funcInSrc = () => {
	return 'funcInSrc';
}

module.exports = funcInSrc;
