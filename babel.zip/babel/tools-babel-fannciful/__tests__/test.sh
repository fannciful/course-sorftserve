unzip ./__tests__/src.zip -d ./

if ! result=$(npx babel ./src --out-dir ./out)
then
  echo 'Babel should be correct configured'
  echo 'All tests failed!'
  exit 1
fi
