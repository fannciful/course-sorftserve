import './App.css';
import { useState, useEffect } from 'react';

export default function App() {
  const [inputElement, setInputElement] = useState('');

  useEffect(() => {
    const savedData = localStorage.getItem('appData');
    if (savedData) {
      setInputElement(savedData);
    }
  }, []);

  const handleInputChange = (e) => {
    const value = e.target.value;
    setInputElement(value);
    localStorage.setItem('appData', value);
  };

  return (
    <div>
      React Marathon, appData: <input 
      size='5'
      value={inputElement}
      onChange={handleInputChange}
      ></input>
    </div>
  );
}
