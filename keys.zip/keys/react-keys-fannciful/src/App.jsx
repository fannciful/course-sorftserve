import './App.css';

export default function App() {
  const items = [
    "Animals",
    "Anime",
    "Anti-Malware",
    "Art Design",
    "Books",
    "Business",
    "Calendar",
    "Cloud Storage",
    "File Sharing",
    "Animals",
    "Continuous Integration",
    "Cryptocurrency"
  ];

  const getUniqueKey = (item, index) => {
    if (items.indexOf(item) !== index) {
      return `${item}-${index}`;
    }
    return item;
  };

  return (
    <div>
      <div>Some List:</div>
      <ul>
        {items.map((item, index) => (
          <li key={getUniqueKey(item, index)}>
            {item}
          </li>
        ))}
      </ul>
    </div>
  );
};
