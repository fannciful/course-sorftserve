import { render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import Calculations from '../components/Calculations';

describe('Calculations Component', () => {
  test('correctly evaluates addition operation with positive numbers', async () => {
    render(<Calculations />);

    const firstInput = screen.getByLabelText('first number');
    await userEvent.clear(firstInput);
    await userEvent.type(firstInput, '15');

    const secondInput = screen.getByLabelText('second number');
    await userEvent.clear(secondInput);
    await userEvent.type(secondInput, '7');

    await userEvent.click(screen.getByText('Evaluate'));
    expect(screen.getByText('22')).toBeInTheDocument();
  });

  test('correctly evaluates subtraction operation with positive numbers', async () => {
    render(<Calculations />);

    const firstInput = screen.getByLabelText('first number');
    await userEvent.clear(firstInput);
    await userEvent.type(firstInput, '20');

    const secondInput = screen.getByLabelText('second number');
    await userEvent.clear(secondInput);
    await userEvent.type(secondInput, '8');

    await userEvent.click(screen.getByLabelText('operation'));
    await userEvent.click(screen.getByText('-'));

    await userEvent.click(screen.getByText('Evaluate'));
    expect(screen.getByText('12')).toBeInTheDocument();
  });

  test('handles zero values correctly', async () => {
    render(<Calculations />);

    const firstInput = screen.getByLabelText('first number');
    await userEvent.clear(firstInput);
    await userEvent.type(firstInput, '0');

    const secondInput = screen.getByLabelText('second number');
    await userEvent.clear(secondInput);
    await userEvent.type(secondInput, '0');

    await userEvent.click(screen.getByText('Evaluate'));
    expect(screen.getByText('0')).toBeInTheDocument();
  });

  test('operation dropdown changes the displayed operation', async () => {
    render(<Calculations />);
    const operationButton = screen.getByLabelText('operation');
    expect(operationButton).toHaveTextContent('+');

    await userEvent.click(operationButton);
    await userEvent.click(screen.getByText('-'));
    expect(operationButton).toHaveTextContent('-');
  });
});