import { render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import ButtonGroup from '../components/ButtonGroup';

describe('ButtonGroup Component', () => {
  test('sets text alignment to left by default', () => {
    render(<ButtonGroup />);
    const textElement = screen.getByTestId('text');
    expect(textElement).toHaveAttribute('align', 'left');

    const leftRadio = screen.getByLabelText('left');
    expect(leftRadio).toBeChecked();
  });

  test('sets text alignment to center when center option is selected', async () => {
    render(<ButtonGroup />);

    const textElement = screen.getByTestId('text');
    await userEvent.click(screen.getByLabelText('center'));
    expect(textElement).toHaveAttribute('align', 'center');
  });

  test('sets text alignment to right when right option is selected', async () => {
    render(<ButtonGroup />);

    const textElement = screen.getByTestId('text');
    await userEvent.click(screen.getByLabelText('right'));
    expect(textElement).toHaveAttribute('align', 'right');
  });

  test('only one alignment option can be selected at a time', async () => {
    render(<ButtonGroup />);

    const leftOption = screen.getByLabelText('left');
    const centerOption = screen.getByLabelText('center');
    const rightOption = screen.getByLabelText('right');

    expect(leftOption).toBeChecked();
    expect(centerOption).not.toBeChecked();
    expect(rightOption).not.toBeChecked();

    await userEvent.click(centerOption);
    expect(centerOption).toBeChecked();
    expect(leftOption).not.toBeChecked();

    await userEvent.click(rightOption);
    expect(rightOption).toBeChecked();
    expect(centerOption).not.toBeChecked();
  });
});