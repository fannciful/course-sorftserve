import { render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import App from '../components/App';

describe('App Component', () => {
  test('displays image when Picture tab is selected by default', () => {
    render(<App />);
    const image = screen.getByAltText('...');

    expect(image).toBeInTheDocument();
    expect(screen.queryByText('Result')).not.toBeInTheDocument();
    expect(screen.queryByTestId('button-group')).not.toBeInTheDocument();
  });

  test('displays Calculations component when Calculations tab is selected', async () => {
    render(<App />);

    const calculationsTab = screen.getByText('Calculations');
    await userEvent.click(calculationsTab);

    expect(screen.getByText('Result')).toBeInTheDocument();
    expect(screen.getByText('Evaluate')).toBeInTheDocument();
    expect(screen.queryByAltText('...')).not.toBeInTheDocument();
    expect(screen.queryByTestId('button-group')).not.toBeInTheDocument();
  });

  test('displays ButtonGroup component when Group tab is selected', async () => {
    render(<App />);

    const groupTab = screen.getByText('Group');
    await userEvent.click(groupTab);

    expect(screen.getByTestId('button-group')).toBeInTheDocument();
    expect(screen.getByText('Align')).toBeInTheDocument();
    expect(screen.queryByAltText('...')).not.toBeInTheDocument();
    expect(screen.queryByText('Result')).not.toBeInTheDocument();
  });

  test('hides components when switching between tabs', async () => {
    render(<App />);

    expect(screen.getByAltText('...')).toBeInTheDocument();
    expect(screen.queryByText('Result')).not.toBeInTheDocument();

    await userEvent.click(screen.getByText('Calculations'));
    expect(screen.queryByAltText('...')).not.toBeInTheDocument();
    expect(screen.getByText('Result')).toBeInTheDocument();

    await userEvent.click(screen.getByText('Group'));
    expect(screen.queryByText('Result')).not.toBeInTheDocument();
    expect(screen.getByTestId('button-group')).toBeInTheDocument();
  });
});