import { z } from "zod";

export const createBookingSchema =
    (availableSlots: string[]) => z.object({
        bookerName: z.string()
            .trim()
            .min(2, { message: 'Booker name must be at least 2 characters long' }),
        bookerEmail: z.string()
            .trim()
            .email({ message: 'Invalid email address' })
            .optional()
            .or(z.literal('')),
        eventName: z.string()
            .trim()
            .min(2, { message: 'Event name must be at least 2 characters long' }),
        eventDate: z.coerce
            .date()
            .refine(
                d => d.getTime() > Date.now(), {
                message: 'Event date must be in the future' 
            }),
        numberOfGuests: z.number({ invalid_type_error: 'Number of Guests must be integer' })
            .int({ message: 'Number of Guests must be integer' })
            .min(1, { message: 'Number of Guests must be at least 1' })
            .max(10, { message: 'Number of Guests must be less than or equal to 10' }),
        timeSlot: z.string({ message: 'Selected time slot is unavailable' })
            .trim()
            .refine((value) => availableSlots.includes(value), { message: 'Selected time slot is unavailable' }),
        eventLink: z.string()
            .trim()
            .url({ message: 'Invalid URL. Please enter a valid event link' })

    })

export type BookingFormData = z.infer<ReturnType<typeof createBookingSchema>>;
