'use client';
import React from 'react';
import styles from './BookingForm.module.css';
import { useEffect, useMemo, useState } from 'react';
import { createBookingSchema } from '@/app/schemas/bookingSchema';
import { zodResolver } from '@hookform/resolvers/zod';
import { useForm } from 'react-hook-form';
import ErrorMessage from '@/app/components/ErrorMessage';

export default function BookingForm() {

  const [availableSlots, setAvailableSlots] = useState([]);
  const [loadingSlots, setLoadingSlots] = useState(true);

  useEffect(() => {
    (async() => {
      try {
        const res = await fetch('/api/time-slots');
        const data = await res.json();
        setAvailableSlots(data ?? []);
      } catch (e) {
        console.error('Failed to fetch available slots:', e);
        setAvailableSlots([]);
      } finally {
        setLoadingSlots(false);
      }
    })();
  }, []);

  const schema = useMemo(() => createBookingSchema(availableSlots), [availableSlots]);

  const {
    register, 
    handleSubmit, 
    formState: {errors},} 
    = useForm({
      resolver: zodResolver(schema),
      defaultValues: {
        bookerName: '',
        bookerEmail: '',
        eventName: '',
        eventDate: '',
        numberOfGuests: undefined,
        timeSlot: '',
        eventLink: ''
      }
    });
    const onSubmit = (data) => {
      alert('Booking successful!');
    }

  return (
    <form onSubmit={handleSubmit(onSubmit)}
    className={styles.form}>
      <div className={styles.inputGroup}>
        <label htmlFor="bookerName" className={styles.label}>
          Booker Name
        </label>
        <input type="text" {...register('bookerName')} id="bookerName" className={styles.input} />
        <ErrorMessage message={errors.bookerName?.message} />
      </div>

      <div className={styles.inputGroup}>
        <label htmlFor="bookerEmail" className={styles.label}>
          Booker Email
        </label>
        <input type="email" {...register('bookerEmail')} id="bookerEmail" className={styles.input} />
        <ErrorMessage message={errors.bookerEmail?.message} />
      </div>

      <div className={styles.inputGroup}>
        <label htmlFor="eventName" className={styles.label}>
          Event Name
        </label>
        <input type="text" {...register('eventName')} id="eventName" className={styles.input} />
         <ErrorMessage message={errors.eventName?.message} />
      </div>

      <div className={styles.inputGroup}>
        <label htmlFor="eventDate" className={styles.label}>
          Event Date
        </label>
        <input type="date" {...register('eventDate')} id="eventDate" className={styles.input} />
         <ErrorMessage message={errors.eventDate?.message} />
      </div>

      <div className={styles.inputGroup}>
        <label htmlFor="numberOfGuests" className={styles.label}>
          Number of Guests
        </label>
        <input type="number" {...register('numberOfGuests', {valueAsNumber: true})} 
        id="numberOfGuests" className={styles.input} />
        <ErrorMessage message={errors.numberOfGuests?.message} />
      </div>

      <div className={styles.inputGroup}>
        <label htmlFor="timeSlot" className={styles.label}>
          Time Slot
        </label>
        <select disabled={loadingSlots} {...register('timeSlot')}
        id="timeSlot" className={styles.input}>
          <option value="">Select a time slot</option>
          {availableSlots.map(slot => (
            <option key={slot} value={slot}>{slot}</option>
          ))}
        </select>
        <ErrorMessage message={errors.timeSlot?.message} />
      </div>

      <div className={styles.inputGroup}>
        <label htmlFor="eventLink" className={styles.label}>
          Event Link (Online)
        </label>
        <input
          id="eventLink"
          className={styles.input}
          type="url"
          {...register('eventLink')}
        />
        <ErrorMessage message={errors.eventLink?.message} />
      </div>

      <button className={styles.button} type="submit">
        Book Event
      </button>
    </form>
  );
}
