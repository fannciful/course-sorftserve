import BookingForm from './components/BookingForm';
import React, { ReactElement } from 'react';

export default function Home(): ReactElement {
  return <BookingForm />;
}
