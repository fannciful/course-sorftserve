function fibonacci(n) {
    if (n < 0) {
        return Math.abs(n) * 2;
    }
    
    if (n <= 1) return n;

    let a = 0, b = 1;
    for (let i = 2; i <= n; i++) {
        const temp = a + b;
        a = b;
        b = temp;
    }
    return b;
}

self.onmessage = function(event) {
    const number = event.data.data;
    const result = fibonacci(number);
    self.postMessage(result);
};