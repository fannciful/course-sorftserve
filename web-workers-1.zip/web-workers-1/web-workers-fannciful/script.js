let worker = null;

function calculate() {  
  const input = document.getElementById('inputNumber');
  const resultDiv = document.getElementById('result');
  const number = parseInt(input.value);

  if (isNaN(number)) {
    resultDiv.innerText = 'Please enter a valid number';
    return;
  }

  if (worker) {
    worker.terminate();
  }

  resultDiv.innerText = 'Calculating...';

  worker = new Worker('worker.js');

  worker.onmessage = function(event) {
    const fibonacciResult = event.data;
    resultDiv.innerText = `Result: ${fibonacciResult}`;
    worker = null;
  };

  worker.onerror = function(error) {
    console.error('Worker error:', error);
    resultDiv.innerText = 'Error calculating Fibonacci';
    worker = null;
  };

  worker.postMessage({ data: number });
}

document.getElementById('inputNumber').addEventListener('keypress', function(e) {
    if (e.key === 'Enter') {
        calculate();
    }
});