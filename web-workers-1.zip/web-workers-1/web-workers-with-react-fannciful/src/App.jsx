import './App.css';
import { useState, useRef } from 'react';

function App() {
  const [result, setResult] = useState('');
  const [isCalculating, setIsCalculating] = useState(false);
  const workerRef = useRef(null);
  const inputRef = useRef(null);

  const handleCalculate = () => {
    const number = parseInt(inputRef.current.value);

    if (isNaN(number)) {
      setResult('Please enter a valid number');
      return;
    }

    if (workerRef.current) {
      workerRef.current.terminate();
    }

    setIsCalculating(true);
    setResult('Calculating...');

    try {
      workerRef.current = new Worker('/worker.js');

      workerRef.current.onmessage = (event) => {
        const fibonacciResult = event.data;
        setResult(`Result: ${fibonacciResult}`);
        setIsCalculating(false);
        workerRef.current = null;
      };

      workerRef.current.onerror = (error) => {
        console.error('Worker error:', error);
        setResult('Error calculating Fibonacci');
        setIsCalculating(false);
        workerRef.current = null;
      };

      workerRef.current.postMessage({ data: number });
    } catch (error) {
      console.error('Failed to create worker:', error);
      setResult('Failed to start calculation');
      setIsCalculating(false);
    }
  };

  return (
    <div className="app">
      <h1>Fibonacci 🌀</h1>
      <input type="number" placeholder="Insert a number" ref={inputRef} />
      <button
        onClick={handleCalculate}
        disabled={isCalculating}
      >
        Calculate
      </button>
      <div className="result" data-testid="result">
        {result}
      </div>
    </div>
  );
}

export default App;