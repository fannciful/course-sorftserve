"use client";
import { useCallback, useMemo, useState } from "react";
import { generateUsers } from "./utils/data";
import dynamic from "next/dynamic";

const VirtualizedList = dynamic(() => import('./components/VirtualizedList'), {
  ssr: false,
});

export default function Home() {
  const [users] = useState(() => generateUsers(100000));
  const [searchTerm, setSearchTerm] = useState("");
  const [itemsPerPage, setItemsPerPage] = useState(5);
  const [scrollToIndex, setScrollToIndex] = useState(undefined);

  const filteredUsers = useMemo(() => {
    if (!searchTerm) return users;
    return users.filter(user =>
      user.name.toLowerCase().includes(searchTerm.toLowerCase())
    );
  }, [users, searchTerm]);

  const findFirstMatchingUserIndex = useCallback((searchTerm) => {
    if (!searchTerm) return undefined;
    
    const exactMatch = users.findIndex(user => {
      const userNumber = user.name.replace('User ', '');
      const searchNumber = searchTerm.replace('User ', '');
      return userNumber === searchNumber;
    });
    
    if (exactMatch >= 0) {
      return exactMatch;
    }
    
    const partialMatch = users.findIndex(user =>
      user.name.toLowerCase().includes(searchTerm.toLowerCase())
    );
    
    return partialMatch >= 0 ? partialMatch : undefined;
  }, [users]);

  const handleSearch = useCallback((e) => {
    const value = e.target.value;
    setSearchTerm(value);

    if (value) {
      const index = findFirstMatchingUserIndex(value);
      setScrollToIndex(index !== undefined ? index : undefined);
    } else {
      setScrollToIndex(undefined);
    }
  }, [findFirstMatchingUserIndex]);

  const handleItemsPerPageChange = useCallback((e) => {
    setItemsPerPage(parseInt(e.target.value));
  }, []);

  const rowHeight = 50;
  const listHeight = rowHeight * itemsPerPage;

  return (
    <div className="container">
      <h1>User List with Virtualization</h1>
      <div className="controls">
        <input
          type="text"
          placeholder="Search by name..."
          value={searchTerm}
          onChange={handleSearch}
        />
        <label htmlFor="perPage">Items per page:</label>
        <select 
          id="perPage"
          value={itemsPerPage}
          onChange={handleItemsPerPageChange}
        >
          <option value={3}>3</option>
          <option value={5}>5</option>
          <option value={8}>8</option>
          <option value={10}>10</option>
        </select>
      </div>
      <VirtualizedList 
        users={users} 
        filteredUsers={filteredUsers}
        searchTerm={searchTerm} 
        height={listHeight}
        rowHeight={rowHeight}
        width={600}
        scrollToIndex={scrollToIndex}
      />
    </div>
  );
}