import { useCallback } from "react";
import { List } from "react-virtualized";
import "react-virtualized/styles.css";

const VirtualizedList = ({ users, filteredUsers, searchTerm, height, rowHeight, width, scrollToIndex }) => {

    const rowRenderer = useCallback(({ index, key, style }) => {
        const user = users[index];
    
        if (searchTerm && !user.name.toLowerCase().includes(searchTerm.toLowerCase())) {
            return null;
        }

        return (
            <div key={key} style={style} className="user-row">
                <p>
                    <strong>{user.name}</strong>
                </p>
                <p>{user.email}</p>
            </div>
        );
    }, [users, searchTerm]);

    return (
        <List
            width={width}
            height={height}
            rowHeight={rowHeight}
            rowCount={users.length} 
            rowRenderer={rowRenderer}
            scrollToIndex={scrollToIndex}
            scrollToAlignment="center"
        />
    );
};

export default VirtualizedList;