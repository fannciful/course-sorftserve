/*
Напишіть функцію combineArray(arr1, arr2), яка приймає 2 масиви і повертає новий масив, 
що складається лише з числових елементів масивів arr1 та arr2.

Приклад:
combineArray([12, "User01", 22, true, -8], ["Index", 6, null, 15]));  // [12, 22, -8, 6, 15]
*/

function combineArray(arr1, arr2) {
    const newArray = arr1.concat(arr2);

     return newArray.filter(element => typeof element === 'number');
}

console.log(combineArray([12, "User01", 22, true, -8], ["Index", 6, null, 15]));  