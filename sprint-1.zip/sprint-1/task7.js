/*

Реалізуйте функцію processArray(arr, factorial), яка приймає першим параметром масив arr, 
а другим параметром - функцію factorial, і обробляє кожен елемент масиву arr функцією 
factorial, повертаючи новий масив (вихідний масив arr не змінюється).

Функція factorial(n) обчислює та повертає факторіал числа n. Наприклад, factorial(4) 
повертає 24.

Приклади:
// determines the factorial of the number n
function factorial(n) { // your code}; 
processArray([1, 2, 3, 4, 5], factorial); // [1, 2, 6, 24, 120]

*/

function factorial(n) {
    if (n === 0 || n === 1) {
        return 1;
    }
    return n * factorial(n - 1);
}

function processArray(arr, factorial) {
    return arr.map(element => factorial(element));
}

console.log(processArray([1, 2, 3, 4, 5], factorial));