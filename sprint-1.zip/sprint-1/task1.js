/*
Реалізуйте функцію getModifiedArray(array), яка приймає довільний масив і повертає масив, 
у якому значення першого елемента дорівнює «Start», останнього елемента — «End», 
а решта елементів мають бути такими ж, як у початковому масиві. 
Початковий масив має залишитися незмінним.

Для коректного проходження всіх тестів не використовуйте метод console.log() у вашому коді.

Test: getModifiedArray([12, 6, 22, 0, -8]);
Result: ['Start', 6, 22, 0, 'End'];
*/

array = [1, 2, 3, 4, 5];

function getModifiedArray(array) {
    const newArray = array.slice();
    newArray[0] = 'Start';
    newArray[newArray.length - 1] = 'End';
    return newArray;
}

console.log(getModifiedArray(array));