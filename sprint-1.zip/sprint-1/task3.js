/*
Знайдіть максимальний інтервал між двома послідовними аргументами.

maxInterv(3, 5, 2, 7); //5
maxInterv(3, 5, 2, 7, 11, 0, -2); //11
maxInterv(3, 5); //2
maxInterv(3); //0

*/

/*
FUNCTION maxInterv(...args):
    IF args.length <= 1:
        RETURN 0
    
    maxDiff ← 0
    FOR i ← 0 TO args.length - 2:
        currentDiff ← ABS(args[i] - args[i + 1])
        IF currentDiff > maxDiff:
            maxDiff ← currentDiff
    
    RETURN maxDiff
*/

const maxInterv = (...args) => {
    if (args.length <= 1) {
        return 0;
    }

    let maxDiff = 0;
    for (let i = 0; i < args.length - 1; i++) {
        const diff = Math.abs(args[i] - args[i + 1]); 
        if (diff > maxDiff) {
            maxDiff = diff;
        }
    }

    return maxDiff;
};

console.log(maxInterv(3, 5, 2, 7));
console.log(maxInterv(3, 5, 2, 7, 11, 0, -2));
console.log(maxInterv(3, 5));
console.log(maxInterv(3));