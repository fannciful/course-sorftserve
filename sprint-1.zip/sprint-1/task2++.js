/*

Припустимо, у вас є масив студентів:

let students = [{
  name: 'Anna',
  languages: ['English', 'Ukrainian'],
  age: 21
}, {
  name: 'Bob',
  languages: ['Polish', 'Spanish'], 
  age: 26 
}, { 
  name: 'Alice', 
  languages: ['Italian', 'German'], 
  age: 18 
}]

Будь ласка, реалізуйте функцію getLanguages. Функція приймає масив студентів як перший 
параметр та умову для студента (функцію). getLanguages повинна повертати масив мов 
від студентів, які задовольняють умові.

Спробуйте використати reduce і не використовувати цикли для вирішення цього завдання.

*/

let students = [{
  name: 'Anna',
  languages: ['English', 'Ukrainian'],
  age: 21
}, {
  name: 'Bob',
  languages: ['Polish', 'Spanish'], 
  age: 26 
}, { 
  name: 'Alice', 
  languages: ['Italian', 'German'], 
  age: 18 
}]

const getLanguages = (students, condition = () => true) => {
    return students.reduce((languages, student) => {
        if (condition(student)) {
            return languages.concat(student.languages);
        }
        return languages;
    }, []);
};

console.log(getLanguages(students)); 