/*
Будь ласка, реалізуйте функцію combineFunctions, яка приймає будь-яку кількість функцій 
як аргументи і повертає функцію, яка є композицією цих аргументів.

Приклад: 
negate = function(x){ return -x; };

halve = function(x){ return x / 2; };

square = function(x){ return x * x; };

double = function(x){ return 2 * x; };

combineFunctions(negate, halve, square) should return a function

square(halve(negate(x)))

Алгоритм:
Прийняття функцій: Функція combineFunctions приймає будь-яку кількість функцій як аргументи
Перевірка вхідних даних: Переконатися, що всі аргументи є функціями
Створення композиції:

Повернути нову функцію, яка приймає вхідне значення
Застосувати всі функції у зворотньому порядку (від останньої до першої)
Результат кожної функції передається як вхідне значення для наступної
Обробка випадку без функцій: Якщо не передано жодної функції, повернути функцію-ідентифікатор
*/

const combineFunctions = (...funcs) => {
    return (x) => {
        return funcs.reduce((result, func) => func(result), x);
    };
}

// Вихідні функції
const negate = function(x){ return -x; };
const halve = function(x){ return x / 2; };
const square = function(x){ return x * x; };
const double = function(x){ return 2 * x; };

// Композиція функцій
const composedFn = combineFunctions(negate, halve, square);

// Еквівалентно: square(halve(negate(x)))
console.log(composedFn(4)); // square(halve(negate(4))) = square(halve(-4)) = square(-2) = 4

// Інший приклад
const composedFn2 = combineFunctions(negate, double);
console.log(composedFn2(5)); // double(negate(5)) = double(-5) = -10