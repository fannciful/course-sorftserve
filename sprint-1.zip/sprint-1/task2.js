/*

Функція filterByN отримує масив цілих чисел, число та параметр (greater, less). Поверніть новий масив, де всі елементи будуть більші/менші за це число.

За замовчуванням, число дорівнює 0, параметр - 'greater'.

Приклади: 
filterNums([-1, 2, 4, 0, 55, -12, 3], 11, 'greater');  // [55]
filterNums([-2, 2, 3, 0, 43, -13, 6], 6, 'less'); // [-2, 2, 3, 0, -13]
filterNums([-2, 2, 3, 0, 43, -13, 6], -33, 'less'); // []
filterNums([-2, 2, 3, 0, 43, -13, 6]); // [2, 3, 43, 6]
filterNums([-2, 2, 3, 0, 43, -13, 6], 23);  // [43]

*/

/*
ФУНКЦІЯ filterNums(array, number, comparison):
    ЯКЩО number === undefined ТО number = 0
    ЯКЩО comparison === undefined ТО comparison = 'greater'
    
    ЯКЩО comparison === 'greater':
        результат = фільтрувати array де element > number
    ІНАКШЕ ЯКЩО comparison === 'less':
        результат = фільтрувати array де element < number
    
    ПОВЕРНУТИ результат
*/


function filterNums(array, number, comparison) {
     const num = number === undefined ? 0 : number;
    const comp = comparison === undefined ? 'greater' : comparison;

    if (comp === 'greater') {
        return array.filter(element => element > num);
    }
    else if (comp === 'less') {
        return array.filter(element => element < num);
    }
    return [];
}

console.log(filterNums([-2, 2, 3, 0, 43, -13, 6], 23));  //[ 55]



