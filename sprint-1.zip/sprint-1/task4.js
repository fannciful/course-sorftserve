/*
Функція приймає довільну кількість рядків і повертає суму їхніх довжин.

Приклади:
console.log(sumOfLen('hello', 'hi')); // 7
console.log(sumOfLen('hi')); // 2
console.log(sumOfLen()); // 0
console.log(sumOfLen('hello', 'hi', 'my name', 'is')); // 16

FUNCTION sumOfLen(...strings):
    total ← 0
    FOR кожного string IN strings:
        total ← total + string.length
    RETURN total

*/

const sumOfLen = (...strings) => {
    let total = 0;
    for (let i = 0; i < strings.length; i++) {
        total += strings[i].length;
    }
    return total;
}

console.log(sumOfLen('hello', 'hi')); // 7
console.log(sumOfLen('hi')); // 2
console.log(sumOfLen()); // 0
console.log(sumOfLen('hello', 'hi', 'my name', 'is')); // 16