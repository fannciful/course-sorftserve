/*

Використовуючи техніку параметрів за замовчуванням, перевантажте функцію overloadedFunc(), 
яка приймає 3 аргументи. Для 1-го аргументу функції встановіть значення за 
замовчуванням [1, 2, 3], для 2-го - значення 2, для 3-го - функцію, яка повертає добуток 
перших двох аргументів, причому функція може множити як масиви, так і числа.

Функція overloadedFunc() повертає результат роботи функції за замовчуванням.

*/

function overloadedFunc(
    first = [1, 2, 3],
    second = 2,
    third = (a, b) => {
        if (Array.isArray(a)) {
            return a.map(item => item * (typeof b === 'number' ? b : 1));
        }
        return a * (typeof b === 'number' ? b : 1);
    }
) {
    return third(first, second);
}

console.log(overloadedFunc([2,4,6,8]));
console.log(overloadedFunc([2,4,6], 3));
console.log(overloadedFunc(10));
console.log(overloadedFunc(8, 3));
