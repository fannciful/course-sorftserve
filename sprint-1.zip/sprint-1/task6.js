/*
Реалізуйте функцію longestLogin(loginList), яка приймає масив логінів користувачів loginList 
і повертає найдовший логін. Якщо в масиві є кілька логінів однакової (найбільшої) довжини, 
повертається той елемент-логін, який має найбільший індекс. 
Підказка: для вирішення задачі можна використати метод reduce().


Приклади:
longestLogin(["serg22", "tester_2", "Prokopenko", "guest"]);   //  Prokopenko

longestLogin(["user1", "user2", "333", "user4", "aa"]);   //  user4
*/


function longestLogin(loginList) {
    return loginList.reduce((longest, current) => {
        if (current.length >= longest.length) {
            return current;
        }
        return longest;
    });
}

console.log(longestLogin(["user1", "user2", "333", "user4", "aa"]));