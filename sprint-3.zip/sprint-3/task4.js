/*
Реалізуйте функцію take(), яка перетворює послідовність ітерованих значень
на послідовність довжиною n.

Test: 
const arr = ['a', 'b', 'c', 'd']; for
(const x of take(2, arr)) {
console.log(x); }
Result: a b
*/

function* take(n, iterable) {
    let count = 0;
    for (const item of iterable) {
        if (count < n) {
            yield item;
            count++;
        }
        else {
            break;
        }
    }
}

const arr = ['a', 'b', 'c', 'd']; for
(const x of take(2, arr)) {
console.log(x); }