/*
Напишіть функцію checkAdult(age), вхідним параметром якої є вік користувача age. 
Функція перевіряє, чи правильно встановлений параметр віку, і якщо він встановлений неправильно, 
має бути створена та виведена у консоль відповідна помилка:

якщо значення віку не встановлено, потрібно створити наступну помилку: "Please, enter your age",
якщо встановлено від'ємне значення віку, потрібно створити наступну помилку: "Please, enter positive number",
якщо було вказано нечислове значення віку, потрібно створити наступну помилку: "Please, enter number",
якщо не було вказано ціле значення віку, потрібно створити наступну помилку: "Please, enter Integer number",
якщо користувачу менше 18 років, потрібно створити наступну помилку: "Access denied - you are too young!".
Якщо немає помилки, у консоль виводиться повідомлення "Access allowed".

У функції реалізуйте обробку можливих винятків, забезпечуючи виведення у консоль назви та опису помилки.

Незалежно від того, чи був параметр віку встановлений правильно чи неправильно,
в кінці перевірки має бути виведене повідомлення "Age verification complete".
*/

function checkAdult(age) {
    try {
        if ((age === undefined) || (age === null)) {
            throw new Error("Please, enter your age");
        }
        if (age < 0) {
            throw new Error("Please, enter positive number");
        }
        if (typeof age !== 'number') {
            throw new Error("Please, enter number");
        }
        if (!Number.isInteger(age)) {
            throw new Error("Please, enter Integer number");
        }
        if (age < 18) {
            throw new Error("Access denied - you are too young!");
        }
        console.log("Access allowed");
    }
    catch (error) {
        console.log("Error " + error.message);
    }
    finally {
        console.log("Age verification complete");
    }
}

checkAdult(25);