/*
Реалізуйте функцію getPromise(delay, message), яка приймає ціле число delay (від 0 до 2000) 
та рядок message, і повертає Promise, який чекає вказану кількість часу (використовуючи 
аргумент delay) та виконується з повідомленням message.

Для коректного проходження всіх тестів не використовуйте метод console.log() у вашому коді.
*/

function getPromise(delay, message) {
    return new Promise((resolve, reject) => {
        setTimeout(() => {
            resolve(message);
        }, delay);
    });
}