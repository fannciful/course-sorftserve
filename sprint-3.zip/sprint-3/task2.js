/*
Напишіть функцію add(x, y), яка приймає два аргументи x та y. 
Функція повинна повертати Promise, який виконується з сумою двох аргументів, 
якщо вони є числами, або відхиляється з повідомленням "Error!" в іншому випадку.
*/

function add(x, y) {
    return new Promise((resolve, reject) => {
        if (typeof x === 'number' && typeof y === 'number') {
            resolve(x + y);
        }
        else {
            reject('Error!');
        }
    })
}

console.log(add(2, 3));
console.log(add(2, "text"));