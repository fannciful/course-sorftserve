/*
Будь ласка, реалізуйте функцію accountPatients, яка приймає кількість ліжок у лікарні та 
повертає масив з двох функцій:

перша функція для додавання пацієнта
друга функція для виписки пацієнта
Спочатку в лікарні немає пацієнтів.

accountPatients повинна відстежувати вільні ліжка в лікарні і кожного разу, 
коли пацієнта приймають або виписують, виводити кількість у консоль, як у прикладах:

Пацієнта прийнято, 34 ліжка доступно
Пацієнта виписано, 54 ліжка доступно
Коли вільних ліжок немає:

Не можна прийняти пацієнта, немає вільних ліжок
Коли намагаються виписати пацієнта, коли в лікарні немає пацієнтів:

Немає пацієнтів для виписки
*/

function accountPatients(totalBeds) {
    let freeBeds = totalBeds;
    let patientsCount = 0;

    function admitPatient() {
        if (freeBeds > 0) {
            freeBeds--;
            patientsCount++;
            console.log(`A patient was admitted, ${freeBeds} beds are available`);
        }
        else {
            console.log('Can not admit a patient, no beds available');
        }
    }

    function dischargePatient() {
        if (patientsCount > 0) {
            freeBeds++;
            patientsCount--;
            console.log(`A patient was discharged, ${freeBeds} beds are available`);
        }
        else {
            console.log('There are no patients to discharge');
        }
    }
    return [admitPatient, dischargePatient];
}

const [admit, discharge] = accountPatients(3);
admit();
admit();
admit();
admit();
discharge();
discharge();
discharge();
discharge();