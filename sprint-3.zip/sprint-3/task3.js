/*
Реалізуйте функцію getAge() для отримання віку користувача. Щоб знайти його вік, вам потрібно 
викликати асинхронну функцію getUser(), яка повертає об'єкт користувача у форматі 
{role: "somerole", id: 1}.

Щоб отримати фактичну інформацію про користувача, вам потрібно викликати іншу асинхронну 
функцію getUserProfile(id), яка використовує id, отриманий з попередньої функції, 
і повертає інформацію про користувача у вигляді об'єкта {name: "Petro", age: 15}. 
Функція getAge() повинна повертати вік користувача.
*/

const {getUser, getUserProfile} = require('./Helper.js');

async function getAge() {
    const user = await getUser();
    const profile = await getUserProfile(user.id);
    return profile.age;
}


/*
Test:
getAge().then(a => console.log(a));
const end = Date.now() + 1000;
while (Date.now() < end) {
    const muchCompute = 1 + 2 + 3;
}
*/
