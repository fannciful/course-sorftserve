console.log('Task 1 executed');
