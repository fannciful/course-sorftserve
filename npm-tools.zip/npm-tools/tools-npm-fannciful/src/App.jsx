import './App.css';
import Info from './components/Info';

function App() {
  return <Info />;
}

export default App;
