export default function Info() {
  return /* some code */;
}
