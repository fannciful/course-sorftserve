console.log('Task 2 executed');
