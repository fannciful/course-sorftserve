console.log('Script 2');
